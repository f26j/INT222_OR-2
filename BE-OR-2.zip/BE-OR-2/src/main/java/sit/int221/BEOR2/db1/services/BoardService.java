package sit.int221.BEOR2.db1.services;

import io.viascom.nanoid.NanoId;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import sit.int221.BEOR2.db1.dtos.BoardDto;
import sit.int221.BEOR2.db1.entities.Board;
import sit.int221.BEOR2.db1.entities.User;
import sit.int221.BEOR2.db1.repositories.BoardRepository;
import sit.int221.BEOR2.db1.repositories.UserRepository;
import sit.int221.BEOR2.exceptions.ApiBadRequestException;
import sit.int221.BEOR2.exceptions.ApiNotFoundException;
import javax.validation.Valid;

import java.util.Optional;

@Service
@Slf4j
public class BoardService {
    @Autowired
    private BoardRepository boardRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ModelMapper modelMapper;

    public Board getBoardById(@PathVariable String id) {
        return boardRepository.findById(id)
                .orElseThrow(() -> new ApiNotFoundException("Board id '" + id + "' not found"));
    }

    @Transactional
    public BoardDto addBoard(@RequestBody @Valid Board board) {
        String userName = SecurityContextHolder.getContext().getAuthentication().getName();
        log.info(userName);
        User user = userRepository.findByUsername(userName)
                .orElseThrow(() -> new ApiBadRequestException("User is required to add a board"));

        board.setUser(user);

        String boardName = board.getName();
        if (boardName == null || boardName.trim().isEmpty() || boardName.length() > 120) {
            throw new ApiBadRequestException("Board name cannot be empty or overlength");
        }

        modelMapper.typeMap(Board.class, BoardDto.class).addMappings(mapper -> {
            mapper.map(Board::getUser, BoardDto::setOwner);
        });

        board.setId(NanoId.generate(10));
        return modelMapper.map(boardRepository.saveAndFlush(board), BoardDto.class);
    }

    @Transactional
    public BoardDto editBoard(@PathVariable String id, @RequestBody @Valid Board board) {
        Board existingBoard = boardRepository.findById(id)
                .orElseThrow(() -> new ApiNotFoundException("Board id '" + id + "' not found"));

        modelMapper.typeMap(Board.class, BoardDto.class).addMappings(mapper -> {
            mapper.map(Board::getUser, BoardDto::setOwner);
        });

        board.setId(existingBoard.getId());
        board.setUser(existingBoard.getUser());
        return modelMapper.map(boardRepository.saveAndFlush(board), BoardDto.class);
    }

    @Transactional
    public void deleteBoard(@PathVariable String id) {
        if (!boardRepository.existsById(id)) {
            throw new ApiNotFoundException("Board id '" + id + "' not found");
        }

        boardRepository.deleteById(id);
    }
}

